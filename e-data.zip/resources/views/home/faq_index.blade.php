@extends('layout.master_front')


@section('section_header')
<h1>Frequently Ask Question (Faq)</h1>
<div class="section-header-breadcrumb">
  <div class="breadcrumb-item active"><a href="#">Home</a></div>
  <div class="breadcrumb-item">Faq</div>
</div>
@endsection
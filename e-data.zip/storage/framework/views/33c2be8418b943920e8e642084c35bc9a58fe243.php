<div class="text-center">
    <div class="spinner-grow text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
    <div class="spinner-grow text-primary" role="status">
        <span class="sr-only">Loading...</span>
      </div>
      <div class="spinner-grow text-primary" role="status">
        <span class="sr-only">Loading...</span>
      </div>
</div>
<?php /**PATH D:\Project\web\e-data\resources\views/misc/loadingBootstrap.blade.php ENDPATH**/ ?>
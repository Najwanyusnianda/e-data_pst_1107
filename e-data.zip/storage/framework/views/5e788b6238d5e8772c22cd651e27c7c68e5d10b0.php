<?php $__env->startSection('section_header'); ?>
<h1>Pencarian Subject</h1>
<div class="section-header-breadcrumb">
  <div class="breadcrumb-item active"><a href="<?php echo e(route('home.home').'/'); ?>">Home</a></div>
  <div class="breadcrumb-item active"><a href="<?php echo e(route('home.home').'/'); ?>">Subject</a></div>
<div class="breadcrumb-item"><?php echo e($subject->subject); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .search-result-text{
      color: #6c5ce7;
      text-decoration: none !important;
  }
  .search-result-text:hover{
    text-decoration: none !important;
      font-weight: bold;
  }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="card">
    <div class="card-header">
      <h4>
        <?php echo e($subject->subject); ?> (<?php echo e(count($data)); ?>)
      </h4>
    
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-condensed">
          <thead>
            <tr style="background-color: #6c5ce7;">
              <th style="color: white;">Judul Tabel</th>
        
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>

                  <td>
                    <?php if($search_result->pdf !=null): ?>
                    <a href="<?php echo e(asset('storage/'.$search_result->pdf)); ?>" class="search-result-text"><?php echo e($search_result->title); ?></a>
                    <?php else: ?>
                    <span ><?php echo e($search_result->title); ?></span>
                    <?php endif; ?>
                 
                  </td>
                 
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <div class="card-footer">
      <?php echo e($data->links()); ?>

    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_front_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\APP DEVELOPMENT\web\e-data\resources\views/search/search_subject.blade.php ENDPATH**/ ?>
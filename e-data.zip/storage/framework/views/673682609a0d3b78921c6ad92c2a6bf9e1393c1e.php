<div class="card card-primary">
    <div class="card-header">
        <div class="form-group">
            <select class="form-control" id="select_bab">
                <option selected="selected" disabled>Pilih Bab Publikasi</option>
                <?php if(!empty($pub_detail->n_bab)): ?>
                    <?php for($i = 0; $i < $pub_detail->n_bab ; $i++): ?>
                        <option value="<?php echo e($i+1); ?>">Bab <?php echo e($i+1); ?></option>

                    <?php endfor; ?>
                    <?php else: ?>

                <?php endif; ?>
            </select>

        </div>
        <h4></h4>
        <div class="card-header-action">
            <a href="#" class="btn btn-icon btn-primary addTableButton mr-3" >
                Tambah Baru
            </a>


        </div>
    </div>
    <div class="card-body" id="table_list_wrapper">
        <?php if(!empty($pub_detail->n_bab)): ?>
        <div class="table-responsive" id="table-by-bab-wrapper">

        </div>
        <?php else: ?>
        <div class="table-responsive" id="table-by-bab-wrapper">

        </div>
        <?php endif; ?>
    </div>
</div>


<script>

</script><?php /**PATH D:\Project\APP DEVELOPMENT\web\e-data\resources\views/publikasi/pub_table/_bab_list.blade.php ENDPATH**/ ?>
<?php $__env->startSection('section_header'); ?>
<h1>Beranda</h1>
<div class="section-header-breadcrumb">
  <div class="breadcrumb-item active"><a href="#">Home</a></div>
  <div class="breadcrumb-item">Beranda</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h2 class="section-title">Pencarian Data</h2>
<p class="section-lead">Pencarian Data melalui kata kunci</p>
<div class="container">
    <form class="SeachForm" action="<?php echo e(route('home.seach_post')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="search-element">
            <div class="form-group">
                <div class="input-group mb-3 ">
                    <input type="text" name="search" id="search" class="form-control form-control-lg pt-4 pb-4"
                        placeholder="Masukkan kata kunci..." aria-label="">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit"><i class="fas fa-search fa-2x"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_front_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\APP DEVELOPMENT\web\e-data\resources\views/home/home.blade.php ENDPATH**/ ?>
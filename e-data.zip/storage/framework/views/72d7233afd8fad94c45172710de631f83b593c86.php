<div class="card author-box card-primary">
    <div class="card-header">
        <span class="badge badge-info badge-sm">
           Update Terakhir: <?php echo e(\Carbon\Carbon::parse($pub_detail->updated_at)
            ->diffForHumans()); ?>

        </span>
        <h4></h4>
        <!--<h4>
             Detail Publikasi

        </h4>-->

        <div class="card-header-action">
            <!--<a href="#" class="btn btn-primary">View All</a>-->
        <a href="<?php echo e(route('admin.publikasi_updateIndex',['pub_id'=>$pub_detail->pub_id])); ?>" class="btn btn-warning ml-auto">
          Update Publikasi
        </a>
          </div>
    </div>
    <div class="card-body">
      <div class="author-box-left">
        <img alt="image" src="<?php echo e($pub_detail->cover); ?>" class="rounded img-thumbnail author-box-picture">
        <div class="clearfix"></div>

        <a href="#" class="btn btn-primary mt-3 ">Download</a>
      </div>
      <div class="author-box-details">
        <div class="author-box-name">
          <a href="#"><?php echo e($pub_detail->title); ?></a>
        </div>
        <div class="author-box-job">
            <span class="text text-muted">(Id :<?php echo e($pub_detail->pub_id); ?>)</span>
            <?php if(!empty($pub_detail->issn)): ?>
            <span class="text text-muted">(ISSN: <?php echo e($pub_detail->issn); ?>)</span>
            <?php else: ?>
            <span  class="text text-muted">( ISSN: - )</span>
            <?php endif; ?>
        
        </div>
        <div class="author-box-description">
          <p><?php echo e($pub_detail->abstract); ?></p>
        </div>
       <!-- <div class="mb-2 mt-3"><div class="text-small font-weight-bold">Follow Hasan On</div></div>
        <a href="#" class="btn btn-social-icon mr-1 btn-facebook">
          <i class="fab fa-facebook-f"></i>
        </a>
        <a href="#" class="btn btn-social-icon mr-1 btn-twitter">
          <i class="fab fa-twitter"></i>
        </a>
        <a href="#" class="btn btn-social-icon mr-1 btn-github">
          <i class="fab fa-github"></i>
        </a>
        <a href="#" class="btn btn-social-icon mr-1 btn-instagram">
          <i class="fab fa-instagram"></i>
        </a>-->
     
        <table class="table table-sm">
            <thead>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>

            </thead>
            <tbody>
                <tr>
                    <td width=40%>No. Publikasi</td>
                    <td width=10%>:</td>
                    <td><?php echo e($pub_detail->pub_no); ?></td>
                </tr>
                <tr>
                    <td width=40%>No. Kategori</td>
                    <td width=10%>:</td>
                    <td><?php echo e($pub_detail->kat_no); ?></td>
                </tr>
                <tr>
                    <td width=40%>Size</td>
                    <td width=10%>:</td>
                    <td>
                        <?php if(!empty($pub_detail->size)): ?>
                        <?php echo e($pub_detail->size); ?>

                        <?php else: ?>
                        <span  class="text text-muted"> Tidak diketahui</span>
                        <?php endif; ?>
                    </td>

          
                </tr>
                <tr>
                    <td width=40%>Tanggal Rilis</td>
                    <td width=10%>:</td>
                    <td>
                        <?php if(!empty($pub_detail->issn)): ?>
                        <?php echo e(\Carbon\Carbon::parse($pub_detail->release_date)->format('j F, Y')); ?>

                        <?php else: ?>
                        <span class="text text-muted" > Tidak diketahui</span>
                        <?php endif; ?>
                    </td>

          
                </tr>
            </tbody>
        </table>
        <div class="w-100 d-sm-none"></div>
        <div class="float-right mt-sm-0 mt-3">
          <a href="#" class="btn">View Posts <i class="fas fa-chevron-right"></i></a>
        </div>
      </div>
    </div>
  </div><?php /**PATH D:\Project\APP DEVELOPMENT\web\e-data\resources\views/publikasi/pub_table/_detailPublikasi.blade.php ENDPATH**/ ?>